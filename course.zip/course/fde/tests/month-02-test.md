# FDE Course — Month 2 Test (Days 31-60)

Answer all 15 questions. Answers are at the end.

---

**Question 1 (Multiple Choice — CRM objects, Day 31).** An imagined clinic uses a CRM to track its patients. A patient calls in with a billing complaint that needs follow-up. Which CRM object would this usually be recorded as?

A) A lead
B) A contact
C) A case
D) An account

**Question 2 (Short Answer — CRM integration patterns, Day 32).** An imagined insurance company wants its CRM to always have the newest customer address, and it also wants its billing system to always have the newest address, no matter which system an employee updates first. Name the integration pattern (one-way or two-way sync) this requires, and explain one problem this pattern creates that a one-way sync would not have.

**Question 3 (Multiple Choice — Ticketing objects, Day 33).** A customer opens a support ticket about a broken login. The support team is swamped, and this particular customer is a large enterprise account under a strict contract. Which ticket field exists specifically to make sure this ticket gets looked at fast enough under that contract?

A) Status
B) Assignee
C) SLA
D) Priority

**Question 4 (Short Answer — Ticketing field mapping, Day 34).** An imagined ticketing tool uses the status values "Open," "Pending," and "Closed." The customer's own system, which you are integrating with, uses "New," "In Progress," "Waiting on Customer," and "Resolved." Explain, in your own words, what field mapping is for here, and give one example of how you might map "Pending" to one of the customer's four statuses, noting that the mapping is not perfectly one-to-one.

**Question 5 (Short Answer — Call-centre basics, Day 35).** Explain, using a short imagined example (for example, a bank call centre), what an IVR is and what an ACD is, and how they usually work together when a customer calls in.

**Question 6 (Scenario — Voice bot transfer, Day 36).** An imagined pharmacy's voice bot is handling a call about a prescription refill. Partway through, the caller asks a question the bot cannot answer, and a human pharmacist needs to take over. The bot has already collected the caller's name, prescription number, and the reason for the call. Should this be a warm transfer or a cold transfer? Explain your choice, and explain what would go wrong for the caller if the opposite choice were made.

**Question 7 (Multiple Choice — Webhooks basics, Day 37).** A ticketing system needs to tell a partner's system the instant a ticket's status changes, without the partner's system constantly asking "has anything changed yet?" Which approach is this?

A) Polling
B) A webhook (push)
C) A batch export
D) A manual CSV upload

**Question 8 (Short Answer — Webhook security, Day 38).** Explain what signature verification on a webhook is for, and explain what a replay attack is in this context, using an imagined example of a webhook that tells a bank's system "payment confirmed" for a given order.

**Question 9 (Scenario — Webhook retries and idempotency, Day 39).** An imagined delivery company sends a webhook saying "order #4521 has shipped." Their system did not get an acknowledgement in time, so it sends the exact same webhook again three seconds later. Your receiving system already processed the first one and updated the order status and sent a confirmation email. What should your system do when the duplicate webhook arrives, and what concept from the lesson makes this safe to design for in advance?

**Question 10 (Short Answer — Webhook receiver design, Day 40).** Describe the "ack fast, queue, and use a dead-letter queue" pattern for designing a webhook receiver, and explain in one sentence why acknowledging fast (before doing the real processing) matters to the sender.

**Question 11 (Multiple Choice — CSV vs JSON, Days 41-44).** An imagined hospital needs to send patient records that include a list of several past visits per patient, where each visit has its own set of several fields (date, doctor, diagnosis). Which format is naturally better suited to this kind of nested, variable-length data?

A) CSV, because it is simpler to open in a spreadsheet
B) CSV, because it always has a fixed number of columns
C) JSON, because it can represent nested structures like a list of visit objects inside one patient record
D) Neither format can represent this kind of data

**Question 12 (Short Answer — Parquet, Days 45-46).** An imagined analytics team needs to run a query that reads only the "total_amount" column across 50 million sales rows, ignoring all other columns. Explain why Parquet's columnar storage would usually make this query faster than reading the same data from a CSV file.

**Question 13 (Scenario — ETL and data quality, Days 47-50).** An imagined retailer's nightly ETL job loads yesterday's sales into a reporting table. This morning, the report shows total sales as zero for an imagined store that was definitely open and selling yesterday. Using the ETL stages (extract, transform, load) and at least one data quality dimension from the lesson, describe how you would investigate where in the pipeline this went wrong, and name the data quality dimension that best describes this specific problem.

**Question 14 (Short Answer — OAuth, Days 51-52).** An imagined scheduling app needs to let a user log in once and then read that user's calendar from a separate calendar provider, without ever seeing or storing the user's calendar password. Name the OAuth flow best suited to this, and explain in one sentence what a refresh token is for in this flow.

**Question 15 (Scenario — Retries, timeouts, and going live, Days 55-60).** An imagined e-commerce company's checkout service calls a third-party tax-calculation API during every order. One day, the tax API becomes very slow but does not fail outright, and because the checkout service keeps waiting and retrying on every slow call, its own threads fill up and checkout starts failing for everyone, even orders that do not need tax calculated. Name two concepts from the lesson (one about timeouts, one about retries or failure isolation) that could have prevented this cascading failure, and briefly explain how each would have helped.

---

## Answer Key

**1. C.** A billing complaint that needs follow-up and resolution is a case (or support issue) linked to the patient, not a lead (someone not yet a customer), a plain contact record (just the person's details), or an account (the organization). The case object exists specifically to track an issue through to resolution.

**2.** This requires a two-way (bidirectional) sync, since either system can be the one updated first and both systems must end up matching. The problem this creates, which a one-way sync would never have, is conflict handling: if the CRM and the billing system are both updated with different addresses at close to the same time, the integration must decide which update wins (for example, by timestamp), and a poorly designed two-way sync can even create an update loop where each system keeps re-sending its version back to the other.

**3. C.** SLA (service level agreement) is the field that tracks the time commitment owed to this specific customer under their contract, separate from priority (which is more about how urgent or important the ticket is in general) and separate from status or assignee, which just track workflow state and ownership.

**4.** Field mapping is the work of translating the ticket statuses used inside this tool into the equivalent statuses the customer's own system expects (and back), so both sides always agree on what state a ticket is in, even though the two systems were never designed to match each other exactly. A reasonable mapping: "Pending" could map to "Waiting on Customer" if the ticket is pending because the team is waiting for more information from the customer, since that is the closest meaning available on the customer's side — though a strong answer should note "Pending" could sometimes mean something closer to "In Progress" depending on why it is pending, showing the mapping is not perfectly one-to-one.

**5.** An IVR (Interactive Voice Response) is the automated system a caller hears first, for example an imagined bank's "press 1 for balance, press 2 to speak to an agent" menu, which collects the caller's choice before any human is involved. An ACD (Automatic Call Distributor) is the system that then takes calls that need a human and routes them to an available, appropriately skilled agent, for example sending a "press 2" caller to the next free agent trained in account issues. They work together in sequence: the IVR gathers the caller's intent first, and the ACD then uses that information to route the call to the right human queue and agent.

**6.** This should be a warm transfer, where the bot (or a system behind it) passes the caller's name, prescription number, and reason for the call directly to the pharmacist before or as the call connects, so the caller does not have to repeat themselves. If a cold transfer were used instead, the caller would be dropped onto the pharmacist's line with none of that context passed along, forcing the caller to re-explain their name, prescription number, and problem from scratch, which feels frustrating and wastes the information the bot had already collected.

**7. B.** This is a webhook (push), because the ticketing system actively sends ("pushes") a notification the instant the status changes, rather than the partner system repeatedly asking ("polling") whether anything is new.

**8.** Signature verification lets the receiving system confirm that a webhook claiming to say "payment confirmed" for an order really came from the genuine sender (for example, the real payment processor) and was not altered in transit, usually by checking a cryptographic signature sent along with the webhook using a shared secret. A replay attack is when someone captures a genuine, correctly signed "payment confirmed" webhook and resends it again later to trick the bank's system into processing the same payment confirmation a second time, even though the signature itself is technically still valid, which is why replay protection (such as checking timestamps or a one-time ID) is a separate concern from the signature check itself.

**9.** The receiving system should recognize the duplicate (for example, by checking the order's shipment event ID or similar identifier it already processed) and safely ignore it, without updating the order status again or sending a second confirmation email. This is safe to design for because of idempotency: designing the webhook handler so that processing the exact same event multiple times produces the same end result as processing it once, which is exactly what retries require to be safe.

**10.** The pattern is: the receiver should acknowledge ("ack") the webhook immediately after confirming it is valid and received, without doing the full processing work yet; it then places the event on a queue for the real processing to happen soon after, separately; and if processing an event keeps failing after retries, that event is moved to a dead-letter queue instead of being lost or retried forever, so someone can investigate it later. Acknowledging fast matters to the sender because most senders (as seen with webhook retries) will treat a slow or missing acknowledgement as a failure and resend the same event, so a fast ack avoids triggering unnecessary duplicate sends.

**11. C.** JSON is naturally suited to this because it can represent nested objects and lists directly, such as one patient record containing a list of several visit objects, each with its own fields — something CSV cannot cleanly represent, since CSV is built around a flat grid of fixed columns and rows, not nested, variable-length structures.

**12.** Parquet stores data column by column rather than row by row, so a query that only needs the "total_amount" column can read just that one column's data straight from disk and skip every other column entirely. A CSV file stores data row by row, so even a query needing only one column still has to read through every full row, including all the unwanted columns, making it much slower for this kind of single-column query over many rows.

**13.** A reasonable investigation path follows the ETL stages in order: first check extract — did the job successfully pull yesterday's raw sales data for that store at all, or did the extract step silently fail or skip that store's source file; then check transform — did the transformation step correctly calculate and keep that store's rows, or did a filter, join, or calculation step accidentally drop or zero them out; then check load — did the transformed data actually get written into the reporting table, or did the load step fail partway through for that store. The data quality dimension that best describes this specific problem is completeness, since data that should exist (that store's sales) is missing from the final result.

**14.** The authorization code flow is best suited here, since it is designed for a case where a user is present and needs to grant one application (the scheduling app) permission to access data in another (the calendar provider) without ever sharing their password with the first application. A refresh token lets the scheduling app get a new, short-lived access token once the original one expires, without forcing the user to log in and approve access all over again.

**15.** Two concepts that would have helped: first, a sensible timeout strategy — setting a reasonable maximum wait time for the tax API call so a single slow call fails fast instead of holding a thread open indefinitely, which directly limits how much damage one slow dependency can do. Second, a circuit breaker (or similar failure-isolation idea from retries/backoff) — detecting that the tax API is repeatedly slow or failing and temporarily stopping new calls to it (or falling back to a default/cached tax estimate) instead of letting every single order keep retrying against an already-struggling service, which is exactly the kind of cascading failure the lesson described as retries making a bad situation worse rather than better.
