# Month 6 Test — Career and Capstone (Days 151-180)

This test covers all of Month 6: FDE interview formats, customer role-play, take-home builds, system design, STAR behavioural interviews, portfolio case studies, mock interviews, offer negotiation, job search planning, and the capstone. 15 questions, mixed format. Answer key is at the end — do not look ahead until you've attempted every question.

---

**Question 1 (Short answer).** What is the core difference between a standard engineering system design interview and an FDE-style system design interview?

**Question 2 (Short answer).** Name the four-part structure used in a STAR behavioural answer, and state which part should usually take up the most time.

**Question 3 (Multiple choice).** In a customer role-play interview, what should you generally do before proposing any solution?
A) State your product's main features confidently
B) Ask open discovery questions to understand the real problem
C) Mention your competitors' weaknesses
D) Quote a price range immediately

**Question 4 (Short answer).** Why is it risky to reveal your walk-away point (your minimum acceptable offer) out loud during a negotiation conversation?

**Question 5 (Multiple choice).** Which of these is generally the EASIEST lever for a company to adjust when its base pay band is strictly fixed?
A) Base salary
B) Internal pay grade policy
C) A one-time joining bonus
D) Company-wide compensation structure

**Question 6 (Short answer).** In a take-home build exercise for an FDE role, why does showing your reasoning and trade-off decisions usually matter as much as, or more than, a perfectly polished final output?

**Question 7 (Short answer).** Describe what an "out of scope" section in a scope document is for, and give one reason it is important even though it only lists things that will NOT be delivered.

**Question 8 (Multiple choice).** What is the main purpose of a runbook in a customer deployment?
A) To document the sales pitch used to win the client
B) To give whoever operates the system day to day clear steps for common situations
C) To replace the need for any success criteria
D) To record the names of everyone interviewed during discovery

**Question 9 (Short answer).** Why should "primary" and "secondary" (safety) success criteria be treated differently, with secondary criteria acting as a gate?

**Question 10 (Short answer).** You are asked "what's your current CTC?" early in a negotiation. Give two different honest, professional ways to respond without directly stating the number.

**Question 11 (Multiple choice).** In a portfolio case study, which of these is the BEST practice for protecting client confidentiality?
A) Use the real company name but remove the logo
B) Rename the customer generically, round numbers, and describe patterns rather than proprietary specifics
C) Only share the portfolio verbally, never in writing, with exact figures
D) Avoid portfolios altogether for any client-based work

**Question 12 (Short answer).** In a 45-minute system design interview, roughly how should the time be divided across clarifying questions, high-level approach, detailed architecture, trade-offs/failure modes, and summary/rollout? Give approximate minute ranges for each.

**Question 13 (Short answer).** Explain the difference between warm outreach and cold applications in a job search, and state one specific signal you'd use to decide which approach fits a given target company.

**Question 14 (Multiple choice).** In the capstone's ROI reasoning approach, why are round, relative numbers (like percentages and "cost units") preferred over specific invented currency figures?
A) Round numbers are always more impressive to executives
B) Specific currency figures are illegal to use in presentations
C) Invented precise figures would have no real basis and could mislead; relative reasoning teaches the pattern honestly
D) Percentages are easier to calculate than currency amounts

**Question 15 (Short answer).** In a capstone-style executive presentation, what should typically come first — the detailed technical architecture or the headline result and recommendation — and why?

---

## Answer Key

**1.** A standard system design interview optimizes for scale and technical elegance in the abstract. An FDE-style system design interview is grounded in one specific real customer's constraints — their existing systems, compliance needs, team skill level, and rollout risk — so the "best" design is the one that integrates safely and realistically with what the customer already has, not just the most technically impressive architecture possible. Clarifying questions and constraint-driven decisions matter as much as the diagram itself.

**2.** Situation, Task, Action, Result (STAR). The Action section should usually take up the most time, since it contains the specific, concrete steps you personally took — this is what the interviewer is most trying to evaluate, and it's the part candidates most commonly under-develop.

**3.** B — Ask open discovery questions to understand the real problem. Proposing a solution before understanding the actual pain point makes any pitch feel generic and makes the customer feel unheard, especially if they've had a bad experience with a previous vendor.

**4.** Revealing your walk-away point tells the other side the lowest number that will still get a yes from you, removing their incentive to offer anything above that minimum. It should stay private and be used only as your own internal decision tool, decided calmly in advance rather than disclosed during the live conversation.

**5.** C — A one-time joining bonus. It doesn't change the company's ongoing payroll structure or set a visible precedent for other employees' base pay, unlike a permanent base salary change, which is why it's often the easiest lever to pull even when the base band truly cannot move.

**6.** FDE take-home builds are usually evaluated on judgment and decision-making under real-world constraints, not just whether the final code or design looks polished. Showing your reasoning — what trade-offs you considered, what you deliberately left out and why, what assumptions you made — demonstrates the thinking process a real customer engagement requires, which is harder to fake and more predictive of job performance than surface polish alone.

**7.** An out-of-scope section explicitly states what will NOT be delivered in the current phase, to prevent future misunderstandings. It matters because customers often assume similar-sounding features are included by default (for example, assuming warranty claims are covered because they resemble repair bookings); writing out-of-scope items down explicitly removes this ambiguity and avoids costly disputes or disappointment later in the engagement.

**8.** B — To give whoever operates the system day to day clear steps for common situations (health checks, metric drops, outages, who to contact), so the deployment doesn't depend on the original build team being available forever.

**9.** Primary criteria (like wait-time reduction) measure the main business value, but strong primary numbers could sometimes be achieved by quietly cutting corners on quality or safety. Secondary (safety) criteria act as a gate — if they're breached, the project pauses for investigation regardless of how good the primary numbers look — specifically to prevent optimizing for an impressive headline metric at the expense of real customer harm or risk.

**10.** Any two of: (1) Redirect to the role's value/scope instead of past pay ("I'd rather focus on the scope and value of this role than my current package"). (2) Share a researched range based on live market signals instead of current pay ("Based on my research for similar roles, I'm expecting a range of..."). (3) Ask the company to share their budgeted range first, so they anchor the conversation instead of you.

**11.** B — Rename the customer generically, round numbers, and describe architecture patterns rather than proprietary specifics. This preserves enough specificity to be convincing while protecting confidential details; option A still exposes the real identity, C is impractical and still risky if numbers are exact, and D unnecessarily discards valuable, legitimate evidence of your work.

**12.** Approximately: 0-5 minutes for clarifying questions and requirements gathering; 5-10 minutes for stating assumptions and a high-level approach; 10-30 minutes for building the detailed architecture; 30-38 minutes for trade-offs, failure modes, and scaling discussion; 38-45 minutes for summary and rollout/deployment discussion.

**13.** Warm outreach is reaching out through an existing connection or direct personal message; cold applications go through public postings with no personal connection. Warm outreach generally converts far better because of the social trust a referral carries, and should be used whenever any real connection path exists. One signal for deciding: if you have any genuine connection (former colleague, shared network, prior interaction) at the target company, use warm outreach; if no connection path exists but the company still strongly matches your targeting fit signals, use a tailored cold application rather than skipping the opportunity.

**14.** C — Invented precise figures would have no real basis and could mislead; relative reasoning (percentages, cost units) teaches the underlying comparison pattern honestly without fabricating specific numbers the presenter has no actual basis for.

**15.** The headline result and recommendation should come first, within the executive summary, before any architecture detail. Busy executive audiences need the main conclusion and the specific decision being asked of them immediately, since they may have limited time or attention; supporting technical detail should follow only for those who want to go deeper, not precede the main point.
