# Month 4 Test: Applied AI and Voice Contact-Centre Deployment

This test covers all of Month 4 (Days 91 through 120): LLM basics, prompting, structured output, RAG, tool calling and agents, evaluation, guardrails and privacy, voice AI, and contact-centre deployment. It mixes multiple choice, short answer, and scenario questions. Attempt every question yourself, in writing, before checking the answer key at the end. Do not look at the answer key first — the value of this test comes from honestly attempting each question under your own effort before checking.

---

## Question 1 (Multiple Choice)

What is "hallucination" in the context of an LLM?

A) The model refusing to answer any question it is unsure about
B) The model generating fluent, confident-sounding text that is actually wrong or made up
C) The model running out of context window space mid-conversation
D) The model taking too long to generate a response

---

## Question 2 (Multiple Choice)

A well-constructed system prompt for a contact-centre bot should include all of the following EXCEPT:

A) Who the bot is and what business it represents
B) What topics it is allowed to help with
C) The exact wording of every possible customer question it might receive
D) What to do when it does not have a confident answer

---

## Question 3 (Short Answer)

In your own words, explain why structured output matters for a voice bot's intent-routing logic, and what structured output does NOT guarantee, even when working correctly.

---

## Question 4 (Multiple Choice)

Which statement about RAG (Retrieval-Augmented Generation) is most accurate?

A) RAG completely eliminates the risk of an AI system giving a wrong answer
B) RAG retrieves relevant information from a trusted source before generating an answer, which significantly reduces but does not eliminate the risk of a wrong answer
C) RAG only works for voice-based systems, not text-based ones
D) RAG replaces the need for any kind of evaluation or testing

---

## Question 5 (Scenario)

An AI agent for a contact centre is given the ability to chain together multiple tool calls: checking a customer's account, updating their billing address, and sending a confirmation SMS, all without a human in the loop. Compared to a system that can only generate text responses, explain what new risk this agent capability introduces, and what kind of safeguard should specifically be strengthened as a result.

---

## Question 6 (Short Answer)

Define a "golden set" in the context of AI evaluation, and explain why it should include deliberately out-of-scope questions, not just normal expected questions.

---

## Question 7 (Multiple Choice)

Which of the following best describes a "guardrail"?

A) A suggestion given to the AI model that it can choose to follow or ignore based on context
B) A hard, fixed rule that holds firm regardless of how a request is phrased, independent of the model's own in-the-moment judgment
C) A feature that makes the AI model respond faster
D) A type of structured output format

---

## Question 8 (Scenario)

A quality audit finds that call recordings used for debugging and training purposes contain customers' full spoken account numbers and OTP codes, unredacted, and are accessible to a broad group of support staff. The bot itself, during live calls, never reads these numbers aloud in full. Explain why this is still a real privacy gap, and what specific fix would address it.

---

## Question 9 (Multiple Choice)

A customer says "fifty" but the system transcribes "fifteen," leading to a wrong routing decision. At which specific layer did the misrecognition occur?

A) The understanding layer (intent classification got the meaning wrong)
B) The speech layer (speech-to-text heard the wrong words)
C) The escalation layer (the bot escalated too early)
D) The authentication layer (identity verification failed)

---

## Question 10 (Short Answer)

Explain why an open prompt ("How can I help you today?") is generally preferred over a rigid keypad-style menu as the main path in a modern voice bot's call flow, and describe one situation where the rigid menu should still be used as a fallback.

---

## Question 11 (Scenario)

A customer calls, clearly frustrated, saying "I already called about this yesterday and nothing was fixed, this is ridiculous." The bot's intent classifier is highly confident (95%) that it understands the technical issue being described and could resolve it directly. Should the bot proceed to resolve the issue itself, or escalate? Explain your reasoning using the relevant escalation trigger.

---

## Question 12 (Multiple Choice)

A voice bot achieves a 90% containment rate, but CSAT on bot-only calls is only 35%, compared to 80% CSAT on escalated calls. What does this pattern most likely suggest?

A) The bot is performing excellently and customers are simply hard to please
B) The bot may be closing calls without genuinely resolving the customer's issue, possibly avoiding necessary escalations
C) The escalation process itself is broken and needs to be removed
D) CSAT surveys are not a reliable metric and should be discontinued

---

## Question 13 (Short Answer)

A bot keeps asking a customer to repeat their account number, over and over, without making progress, before the call eventually drops. Describe the two separate failure modes likely happening here, and the first investigative step for each.

---

## Question 14 (Scenario)

Suryanagar Power's normal busy-hour call volume is 100 calls. A major citywide outage is expected next week, historically pushing volume up to around 450 calls an hour during past similar events. Using the capacity planning principles from this month, what capacity should the system be planned for, and what should happen if volume exceeds even that planned capacity?

---

## Question 15 (Scenario, FDE Synthesis)

A client is thrilled that their new RAG-based insurance bot achieved strong pilot results answering policy coverage questions. They now want to expand it, using the same underlying system with no additional changes, to also discuss likely settlement amounts for claims, arguing that strong pilot performance in one area proves the system is generally reliable. As the FDE on this project, how do you respond? Your answer should address both the applied AI considerations and the deployment/judgment considerations involved.

---
---

# Answer Key

### Answer 1: B

Hallucination is specifically about the model generating fluent, confident-sounding text that is actually wrong or made up — not refusing to answer, not running out of context space, and not being slow. This single characteristic is the underlying reason RAG, evaluation, and guardrails are all necessary safeguards built around LLMs.

### Answer 2: C

A good system prompt defines the bot's identity, scope, and behaviour when uncertain — but it cannot and should not try to list the exact wording of every possible customer question, since real customer language is too varied and unpredictable to enumerate in advance. Good prompting works through clear instructions and principles (plus a few well-chosen examples), not an exhaustive list of every possible input.

### Answer 3

Structured output matters because it lets a voice bot's intent-routing logic reliably read and act on the model's response in a predictable format (like specific fields for detected intent and confidence), rather than needing to guess at meaning from loosely worded free text. This is what connects the AI's language understanding cleanly to the rest of the system (routing, backend decisions, escalation triggers). However, structured output only guarantees the SHAPE of the response is usable — it does not guarantee the VALUES inside that structure (the detected intent, the confidence score) are actually correct. Content accuracy still needs to be verified separately through evaluation.

### Answer 4: B

RAG grounds answers in real, retrieved information, which significantly reduces — but does not eliminate — the risk of a wrong answer, since the system can still retrieve the wrong passage, misinterpret a correct passage, or be grounded in outdated documents. RAG works for both voice and text systems, and it does not replace the need for evaluation; the two work together, not as substitutes for each other.

### Answer 5

The new risk introduced by agent capability is that the system can now actually DO something wrong in the real world — update the wrong account, send a message to the wrong recipient, or chain together an unintended sequence of actions — rather than just saying something incorrect, which is a more contained risk. As real-world capability increases, the potential damage from an error increases too. This means hard, fixed guardrails (rules that do not depend on the model's own judgment and hold firm regardless of context) should be specifically strengthened, especially around irreversible or sensitive actions like account changes, to prevent the agent's added power from translating into real, potentially irreversible harm.

### Answer 6

A golden set is a carefully chosen, trusted set of example questions paired with correct, verified answers, used specifically to measure an AI system's quality through evaluation. It should include deliberately out-of-scope questions because the ONLY correct system behaviour for these is to recognise them as out-of-scope and escalate to a human — testing this directly and measurably verifies that guardrails and scope boundaries actually hold in practice, rather than just existing as untested assumptions on paper. An answer attempted for an out-of-scope question, even if it sounds reasonable, should count as a failure in this part of the evaluation.

### Answer 7: B

A guardrail is a hard, fixed rule that holds the same way regardless of how a request is phrased, built independently of the model's own in-the-moment judgment. This is different from a flexible suggestion the model might choose to follow, and it has nothing to do with response speed or output formatting. Guardrails exist specifically because relying on the model's judgment alone to catch every manipulation attempt is risky — a fixed rule closes off that risk entirely.

### Answer 8

This is still a real privacy gap because privacy protection must be addressed at multiple separate layers: what is said live during the call, and what is captured and stored afterward in recordings and transcripts, are two different layers. The bot's good live behaviour (never reading sensitive numbers aloud in full) only protects the LIVE-call layer — it does nothing to protect data that was already spoken by the CUSTOMER themselves and then captured in full within the STORED recording. The specific fix needed is automatic redaction of sensitive spoken data (account numbers, OTP codes, and similar) within stored transcripts and recordings, so this stored layer is also protected, independent of what the bot itself says live.

### Answer 9: B

This is a speech-layer misrecognition — speech-to-text heard the wrong words entirely ("fifteen" instead of "fifty"). This is different from an understanding-layer problem, where the words would have been transcribed correctly but misclassified in meaning. Correctly identifying which layer failed is the necessary first step before choosing the right fix (STT tuning and number confirmation for a speech-layer issue, versus intent classifier training for an understanding-layer issue).

### Answer 10

An open prompt is generally preferred because it is faster for the customer (one natural sentence instead of listening through a long menu of options) and lets the bot use its intent-understanding capability directly, which is the real value a modern voice bot adds over an old-style keypad menu. A rigid keypad-style menu should still be used as a fallback specifically when the open-prompt approach fails — for example, if speech understanding repeatedly cannot determine the customer's intent after a reasonable number of attempts, falling back to a simple, reliable menu-style prompt (or allowing keypad presses) provides a safety net that does not depend on the more flexible but less certain open-ended understanding working correctly every time.

### Answer 11

The bot should escalate to a human, even though its intent confidence is high. This matches the "negative sentiment detected" escalation trigger — the customer's tone clearly signals frustration and a sense of being let down (mentioning a repeat call with no resolution), and this kind of situation often needs a human's empathy, judgment, and flexibility (such as offering an apology or a goodwill gesture) that a scripted bot response cannot genuinely provide, even if the bot technically understands and could answer the underlying technical issue correctly. High intent confidence does not override a sentiment-based escalation trigger.

### Answer 12: B

A very high containment rate paired with very low CSAT specifically on bot-only calls, especially when escalated-call CSAT is much higher, is a classic warning sign that the bot may be closing calls with quick, unhelpful, or incomplete answers rather than genuinely resolving the customer's issue, possibly avoiding escalations it should actually be triggering. This pattern should prompt reviewing actual call transcripts and checking whether escalation triggers are being appropriately applied, not simply accepting the high containment number as a standalone success, and not concluding the escalation process itself is the problem.

### Answer 13

The first failure mode is looping — the bot repeating the same account-number request without making progress, likely because an earlier answer was misunderstood or a backend check is failing or timing out, causing the bot to retry the same step repeatedly. The first investigative step is pulling the call transcript and recording to see exactly which step is repeating, and checking backend system response times and logs at those exact moments to see if a slow or malformed response is driving the repeated retries. The second failure mode is the dropped call at the end — likely caused by the bot's own call-handling process hitting an internal time limit while waiting on a backend response that never properly completes. The first investigative step here is checking whether this drop happens consistently at the same step across multiple similar calls (pointing to an internal bug) versus randomly across different steps (pointing to an external network cause).

### Answer 14

Using the three-to-five times buffer guideline above normal busy-hour volume, and specifically informed by the real historical spike data showing past events reaching around 450 calls an hour, the system should be planned for at least that historical peak, ideally with some additional safety margin above it (for example, planning for around 500 calls an hour) to account for the possibility of an even larger event than history has shown so far. If volume exceeds even this planned capacity, the system should trigger a planned graceful degradation mode — automatically switching to a shorter, simplified flow (such as a quick pre-checked status update plus a callback offer) that uses fewer resources per call, allowing it to keep serving a larger number of callers in a reduced but still useful way, rather than letting the full system run normally until it eventually crashes and serves nobody at all.

### Answer 15

A strong answer addresses both dimensions clearly. On the applied AI side: strong pilot results answering policy coverage questions do not automatically prove the system is ready to handle a fundamentally different, higher-stakes task like discussing settlement amounts, which involves financial judgment calls rather than document-grounded factual answers — this is a different kind of risk requiring its own dedicated golden set, evaluation, and guardrails specifically built and tested for this new topic area, not simply assumed to be covered by the existing system's general competence. On the deployment and judgment side: expanding scope should follow the same staged, evidence-based discipline as any other rollout — building and verifying the new capability's guardrails and evaluation first, then piloting the expansion at a small scale before any full rollout, rather than expanding directly to full scale based on unrelated pilot success in a different, lower-risk area. A complete answer should also note the real business and legal risk of a confidently wrong answer about a settlement amount, and should propose this staged path clearly and respectfully to the client, rather than simply refusing the request outright or agreeing to it without the proper safeguards in place.
