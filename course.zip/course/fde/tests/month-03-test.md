# Month 3 Test — Days 61 through 90

This test covers all of Month 3: cloud basics, Docker and containers, environments and secrets, CI/CD, monitoring and alerts, deployment models, and cost basics. There are 15 questions, mixing multiple choice, short answer, and scenario questions. Write or think through your answer to each question before checking the answer key at the end. No real prices, real statistics, or real company data are used anywhere in this test — all numbers are made up and rounded for teaching purposes only.

## Questions

**1. (Multiple choice — cloud basics)** Which of these best describes "pay-as-you-go" cloud billing?
A. You pay a single fixed price upfront, no matter how much you use the service.
B. You are billed based on actual measured usage, similar to a taxi meter.
C. You only pay if the service fails to work correctly.
D. You pay a random amount decided by the provider each month.

**2. (Multiple choice — Docker)** What is the correct relationship between a container and an image?
A. A container and an image are exactly the same thing, just different names.
B. An image is a running, live instance; a container is the saved blueprint it's created from.
C. An image is the saved, reusable blueprint; a container is a live, running instance created from that image.
D. A container can only ever be created from exactly one image, and no image can be reused.

**3. (Short answer — environments)** Explain, in two or three sentences, the difference in purpose between a staging environment and a production environment, and why staging should closely mirror production rather than being a loose approximation.

**4. (Short answer — secrets)** Why are secrets, such as passwords and access keys, typically kept separate from a container's regular code and configuration, and supplied only at the moment the container starts running?

**5. (Multiple choice — CI/CD)** A team wants to release a change where the main risk is a clean technical cutover to an entirely new underlying system, and they want an instant, fully-ready fallback if something goes wrong. Which deployment pattern best fits this specific need?
A. Canary release
B. Blue-green deployment
C. Shadow testing
D. A/B testing

**6. (Scenario — CI/CD)** Two days into a gradual rollout of a new voice bot prompt, at 40 percent of real traffic, the team notices a real, confirmed problem affecting real customers. What should happen first: rolling back to the previous version, or investigating the exact root cause? Explain your reasoning in two or three sentences.

**7. (Multiple choice — monitoring)** Which statement correctly distinguishes a metric from a log?
A. A metric is a detailed, timestamped record of what happened; a log is a single number tracked over time.
B. A metric is a single, repeated number tracked over time; a log is a detailed, timestamped record of what actually happened.
C. Metrics and logs are two names for the same thing.
D. A metric only exists for cost data; a log only exists for errors.

**8. (Short answer — alerts)** What is "alert fatigue," and why is setting alert thresholds too sensitively a real problem, even though it might seem safer to be alerted about everything?

**9. (Scenario — on-call)** You are on-call and an alert fires showing response delay has climbed above its normal range for several minutes. Call volume on the dashboard looks completely normal. Describe, in two or three sentences, what you would check next and why ruling out call volume first is a useful step.

**10. (Multiple choice — deployment models)** A healthcare client needs patient data to remain on their own premises for compliance reasons, but also wants flexible, easily scalable processing for the rest of their system. Which deployment model best fits this situation?
A. Fully on-premises
B. Fully cloud-based
C. Hybrid
D. Multi-cloud with three separate providers

**11. (Short answer — total cost of ownership)** A client says cloud must be cheaper than on-premises because "we don't have to buy equipment." Explain, in two or three sentences, why this comparison is incomplete without considering total cost of ownership.

**12. (Multiple choice — cost basics)** In a shop analogy, which of the following is the best example of a variable cost, as opposed to a fixed cost?
A. Monthly shop rent, which stays the same regardless of sales.
B. A one-time licence fee paid once a year.
C. Ingredient cost, which rises and falls with how many items are actually made and sold.
D. The cost of the shop's signboard, paid once.

**13. (Scenario — cost optimization)** A voice bot's compute is sized for 500 simultaneous calls, but real usage data over six months shows the actual peak has never gone above 180. Describe what you would do, and name one safety measure you would add alongside reducing the size, so the change doesn't create new risk.

**14. (Multiple choice — reliability)** Using a simplified round-number month of 1,000 hours, roughly how much downtime is allowed under a 99.9 percent uptime promise?
A. About 100 hours
B. About 10 hours
C. About 1 hour
D. About 6 minutes

**15. (Scenario — disaster recovery)** A contact centre's voice bot backs up its call-log database once every 24 hours. A serious failure corrupts the database at 3 p.m., 15 hours after the last backup. The business has agreed that losing up to 6 hours of recent call data is tolerable. Is the current backup frequency actually meeting the business's stated tolerance? If not, what specific change would you recommend, and what is this recovery target called?

---

## Answer Key and Explanations

**1. Answer: B.** Pay-as-you-go means billing is based on actual, measured usage — like a taxi meter charging for the distance or time actually traveled — not a fixed upfront price (A), not tied to failure (C), and not random (D). This is the foundation of how most cloud billing works, covered in Day 81.

**2. Answer: C.** An image is the saved, reusable blueprint — like a recipe card — and a container is an actual, live, running instance created from that image. Many containers can be created from the same single image, which rules out D, and A and B both reverse or flatten the correct relationship. Covered in Day 85 and reviewed in Day 89.

**3. Sample answer:** A staging environment is used to test a system end to end under realistic, production-like conditions before anything reaches real customers, including deliberately testing failure scenarios. A production environment is the real, live system actual customers depend on, where mistakes have real consequences. Staging needs to closely mirror production because the whole point of staging is to catch problems before customers see them — if staging is too different from the real setup, realistic problems may never show up during testing, defeating its purpose. Covered in Day 85.

**4. Sample answer:** Secrets are sensitive and shouldn't sit in plain, readable text inside code or build files, where anyone who can see those files could also see the secret. Keeping them separate, and supplying them only at startup from a dedicated, protected location, limits who and what can access them, and makes it possible to update or rotate a secret (like a changed password) without needing to rebuild or redeploy the application's actual code. Covered in Day 88.

**5. Answer: B.** Blue-green deployment keeps two full, identical versions ready and switches all traffic instantly between them, with an equally instant path back — ideal for a clean technical cutover needing a guaranteed, fully-ready fallback. Canary release (A) is better suited to gradually learning from varied real behaviour, which isn't the main concern described here. Shadow testing (C) and A/B testing (D) are about comparing or validating behaviour, not about an instant cutover with a ready fallback. Covered in Day 86.

**6. Sample answer:** Rolling back should happen first. Every moment the problematic version keeps serving real traffic, more real customers are affected, so the first priority is stopping that ongoing impact immediately by returning to the previous, known-working version. Calm, thorough root-cause investigation should happen afterward, using data already collected, once customers are no longer being affected by the live problem. Covered in Day 86 and Day 87.

**7. Answer: B.** A metric is a single, repeated number tracked over time (like call volume or response delay), giving a quick signal about system health. A log is a detailed, timestamped record of exactly what happened, used to investigate the specific cause behind something a metric flagged as unusual. A, C, and D all misstate or flatten this distinction. Covered in Day 87.

**8. Sample answer:** Alert fatigue is what happens when alerts fire too often for things that don't actually matter, causing people to start ignoring or tuning out notifications. This is a real problem because by the time a genuinely serious alert fires, it may receive the same reduced attention as all the unimportant ones before it — over-sensitive alerting can make a team less responsive to real problems, not more, which is why thresholds should be set based on real historical "normal" behaviour rather than maximum sensitivity. Covered in Day 87.

**9. Sample answer:** With call volume normal, the next step is to dig into logs from the time window when the delay started, looking for a specific pattern — such as one particular dependency (like the language model service) responding more slowly than usual. Ruling out call volume first is useful because it quickly eliminates one simple, common explanation ("just more traffic"), narrowing the investigation toward a more specific internal cause rather than searching broadly and inefficiently. Covered in Day 87.

**10. Answer: C.** Hybrid deployment deliberately combines cloud and on-premises, keeping the compliance-sensitive patient data on the client's own premises while running the more flexible, scalable processing in the cloud. Fully on-premises (A) would sacrifice flexible scaling across the whole system unnecessarily, fully cloud-based (B) wouldn't satisfy the on-premises compliance requirement, and multi-cloud with three providers (D) adds unrelated complexity without addressing the actual stated need. Covered in Day 90.

**11. Sample answer:** Not buying equipment upfront is only one part of the real comparison. Cloud costs include ongoing, usage-based billing that needs active management to avoid waste, while on-premises costs include not just the equipment purchase but also less obvious costs like maintenance, staff time, and eventual replacement. A fair comparison requires total cost of ownership over a realistic time period on both sides, not just the first, most visible number. Covered in Day 90.

**12. Answer: C.** Ingredient cost rises and falls with how many items are actually made and sold, making it variable. Rent (A), a licence fee (B), and a signboard (D) are all examples of fixed costs that stay the same regardless of how much is sold. Covered in Day 81 and Day 82.

**13. Sample answer:** Since real usage data over six months shows a peak of 180, far below the current sizing of 500, this is a clear right-sizing opportunity — the compute should be resized closer to the observed real peak, with a reasonable safety margin (for example, sized comfortably above 180, not exactly at 180). The safety measure to add alongside the reduction is autoscaling, so the system can temporarily grow further during a rare, unexpected spike rather than being permanently oversized just to cover that rare case. Covered in Day 82.

**14. Answer: C.** Using a simplified 1,000-hour month, 99.9 percent uptime allows one-tenth of one percent downtime, which is about 1 hour. 10 hours (B) would correspond to 99 percent uptime, and 6 minutes (D) is closer to what a much stricter promise like 99.99 percent would allow. 100 hours (A) would be far too loose for a 99.9 percent promise. Covered in Day 83.

**15. Sample answer:** No, the current backup frequency is not meeting the business's stated tolerance. With backups taken once every 24 hours, up to a full day's worth of data could be lost in the worst case, but in this specific incident, 15 hours of call data was actually lost — well beyond the agreed 6-hour tolerance. The recommended change is to back up more frequently, for example every few hours, so that in a worst-case failure, no more than about 6 hours of data could ever be lost. This recovery target — how much recent data can be afforded to lose — is called the Recovery Point Objective (RPO), and it should be distinguished from the Recovery Time Objective (RTO), which is about how long the system can be unavailable, a separate target not addressed by backup frequency alone. Covered in Day 84.
