# Month 5 Test: Customer Delivery (Days 121-150)

This test covers all of Month 5: scoping/SOWs, pilots, demos, security/compliance/DPDP, reliability/SLAs/incidents, runbooks, training customer teams, ROI, and escalations. 15 questions, mixed format. Answer key with full explanations is at the end.

---

**Question 1.**
A Statement of Work (SOW) for a voice bot pilot defines the project's scope. Which of the following BEST describes why a clear scope matters before work begins?
A) It guarantees the project will have zero problems during delivery.
B) It creates a shared, written understanding of what will and won't be delivered, reducing disagreement later about what was promised.
C) It is mainly a legal formality with little practical day-to-day use.
D) It replaces the need for any further communication with the customer during the project.

**Question 2.**
True or False: A pilot project and a full production rollout should generally be scoped and measured using the exact same success criteria, since the underlying technology is the same.

**Question 3.**
During a product demo to a customer's leadership team, the live system unexpectedly fails to respond. What is the BEST immediate response?
A) Keep retrying the same action repeatedly until it works, without saying anything to the audience.
B) Calmly acknowledge the issue, switch to a backup (recording, screenshots, or a second environment), and continue without panicking.
C) End the demo immediately and reschedule without explanation.
D) Blame the customer's internet connection even if you are not sure that is the cause.

**Question 4.**
Short answer: Explain, in 2-3 sentences, why "the system works correctly" and "the system is compliant with data protection regulations" (such as DPDP, the Digital Personal Data Protection law) are two separate questions that both need to be answered before go-live.

**Question 5.**
Which of the following is the BEST definition of an SLA (Service Level Agreement) in a customer-facing AI project context?
A) A technical document only engineers need to read.
B) A written commitment defining the expected level of service (such as uptime or response time), what happens if it isn't met, and how it will be measured.
C) A marketing document describing the system's best-case performance.
D) An internal engineering checklist with no customer visibility.

**Question 6.**
True or False: A well-run incident response should prioritize finding and resolving the technical root cause before spending any time communicating with the affected customer.

**Question 7.**
Short answer: What is the key difference between a "runbook" and general system "documentation"? Give one example of content that belongs in each.

**Question 8.**
A runbook's Trigger section should ideally include more than one way to detect that an incident has started. Why is this good practice? Give one concrete reason.

**Question 9.**
When handing off a runbook to a customer's on-call team, which of the following is a "hidden gap" most likely to cause a well-written runbook to fail in practice?
A) The runbook uses too many short sentences.
B) The customer's on-call staff do not actually have working login access to the tools or dashboards the runbook references.
C) The runbook has too many sections.
D) The runbook was written by an FDE instead of an engineer.

**Question 10.**
Short answer: Name and briefly explain two of the four core adult learning principles that explain why lecture-only training often fails to build real skill.

**Question 11.**
What is "spaced repetition," and why is it especially useful for training people on a skill (like following an incident runbook) that they will only use occasionally?

**Question 12.**
Which of the following is the STRONGEST, most defensible way to claim a cost saving from an AI deployment that automated a share of customer calls?
A) "We automated 40% of calls, so we saved 40% of our total agent budget."
B) "Customer satisfaction went up, so we must have saved money somewhere."
C) "Because of this automation, we avoided a previously planned hiring increase of 3 agents, which is documented in our existing staffing budget."
D) "The system works well, so savings can be assumed."

**Question 13.**
Short answer: Name two of the common ROI pitfalls covered in the course (for example, double-counting, ignoring hidden costs, assuming automation equals savings automatically, using too short a time window, or comparing against an unrealistic baseline), and briefly explain one with an example.

**Question 14.**
In an escalation involving both a technical incident and a frustrated customer stakeholder, which statement BEST describes how the roles of account manager, FDE, and engineering should typically divide the work?
A) Engineering should personally handle all customer communication, since they understand the system best.
B) The account manager manages the business relationship and expectations, the FDE bridges technical and business understanding and coordinates the right response, and engineering focuses on deep technical diagnosis and fixing — usually working in parallel, not strictly in sequence.
C) Only the most senior person involved should do everything, to avoid confusion.
D) The FDE should avoid talking to the customer directly and let engineering handle all communication.

**Question 15.**
Short answer: Describe, in 3-4 sentences, what "de-escalation" means in a tense customer conversation, and explain why acknowledging the customer's feelings should typically come BEFORE a detailed technical explanation.

---
---

# ANSWER KEY

**Answer 1: B.** A clear scope creates a shared, written understanding between the customer and the delivery team about what will and won't be delivered, which reduces the risk of disagreement or misaligned expectations later. It does not guarantee a problem-free project (A is wrong), it is a practical working document used throughout delivery, not just a legal formality (C is wrong), and it does not eliminate the need for ongoing communication (D is wrong) — in fact, good scoping supports better communication by giving both sides a shared reference point.

**Answer 2: False.** A pilot is typically scoped as a smaller, time-boxed test to prove feasibility and learn before committing to a full rollout, so its success criteria are usually different (and often more limited or exploratory) than a full production rollout's criteria, which must account for scale, long-term reliability, full operational support, and broader business impact. Using identical criteria for both ignores the different purposes these two stages serve.

**Answer 3: B.** Calmly acknowledging the issue and switching to a prepared backup (such as a recording, screenshots, or a secondary environment) keeps the demo professional and shows preparedness under pressure, which is reassuring to a customer's leadership team. Repeating the same failing action silently (A) wastes time and looks unprepared; ending the demo abruptly (C) wastes the opportunity and looks unprofessional; blaming something without being sure of the cause (D) risks being wrong and looking unprofessional or dishonest.

**Answer 4:** These are separate questions because a system can function perfectly from a technical standpoint — correctly understanding and responding to callers — while still handling, storing, or processing personal data in ways that violate data protection law, such as DPDP, if proper consent, storage limits, or access controls aren't in place. Compliance is a legal and process question (how data is handled, who can access it, how long it's kept, what consent was obtained), while correct functioning is a technical question (does the system do what it's supposed to do) — passing one does not guarantee passing the other, and both must be explicitly verified before go-live.

**Answer 5: B.** An SLA is a written commitment defining the expected level of service (such as uptime or response time), the consequences if that level isn't met, and how performance will be measured — it is a customer-facing commitment, not merely an internal engineering document (A and D are wrong), and it is a binding commitment, not a best-case marketing description (C is wrong).

**Answer 6: False.** A well-run incident response treats technical resolution and customer communication as parallel priorities, not a strict sequence where communication waits until the technical fix is complete. Customers who are left uninformed while a problem is ongoing tend to become significantly more frustrated, regardless of how well the eventual technical fix goes — so proactive, honest communication should happen alongside the technical work, not only after it concludes.

**Answer 7:** A runbook is a short, specific, action-focused guide for responding to ONE known type of incident, meant to be used quickly under pressure — for example, the exact steps to diagnose and fix an ASR (speech recognition) service outage. Documentation explains HOW a system works in general, for learning and understanding, and can be longer and more detailed — for example, an explanation of how the overall voice bot pipeline routes a call from speech recognition through to the final spoken response. Runbook content is "what to do right now"; documentation content is "how this works, in general."

**Answer 8:** Including more than one detection path matters because automated monitoring systems can fail, lag, or have a misconfigured threshold (for example, an alert firing late because its threshold was set too high), and relying on a single detection method risks missing or delaying recognition of a real incident. Adding a human-reported trigger (such as a floor supervisor noticing repeated customer complaints) as a backup detection path catches cases the automated system might miss or delay.

**Answer 9: B.** A runbook can be extremely well-written in terms of language, structure, and detail, but if the customer's on-call staff don't actually have working access to the tools, dashboards, or systems the runbook references, they will be stuck at the very first step regardless of how good the writing is. This is a common, easily overlooked gap that must be checked and tested before handoff, not assumed to be fine because access was "granted on paper." The other options (short sentences, number of sections, who wrote it) are not inherently problems and do not reliably predict runbook failure.

**Answer 10:** Any two of the following four, with explanation: (1) Adults need to know WHY before HOW — they engage better when they understand the purpose of a task before learning its steps, rather than being told to simply follow steps because "it's required." (2) Adults learn by connecting new material to what they already know — bridging new concepts to familiar prior experience helps the new material make sense and stick. (3) Adults need hands-on practice, not just explanation — listening to or watching a task described builds understanding, but doing the task themselves builds the actual skill and confidence needed later. (4) Adults learn better in smaller, spaced sessions than one long marathon session — a single long session tends to result in most content being forgotten quickly, while shorter sessions spread over time with practice in between retain much better.

**Answer 11:** Spaced repetition means revisiting the same material more than once, with growing gaps of time between each review (for example, a few days, then about two weeks, then monthly), rather than learning something only once and never again. It is especially useful for infrequently-used skills, like following an incident runbook that might only be needed once every few months, because people naturally forget information they don't use regularly (the "forgetting curve") — without periodic refreshers or drills, by the time a real incident actually happens, the skill learned in a single training session may have faded significantly, making periodic spaced practice essential for keeping it sharp and ready when genuinely needed.

**Answer 12: C.** This option ties the automation directly to a real, independently verifiable business decision — an existing staffing budget that documented a planned hiring increase which was avoided. Option A assumes automation automatically equals proportional cost savings without confirming any actual staffing or budget change occurred, which is a common and misleading ROI mistake. Option B draws an unsupported causal link between two different metrics without any real connecting evidence. Option D assumes savings exist simply because the system functions correctly, which (as covered throughout the ROI lessons) is not a valid basis for a financial claim — technical success and financial value are different questions.

**Answer 13:** Any two of the following five, with one example: (1) Double-counting — claiming the same underlying benefit twice in two different forms, such as counting "agent hours saved" as a cost saving and then separately counting "customers served faster because of those same saved hours" as an independent revenue gain, when both trace back to the same root cause. (2) Ignoring hidden costs — such as forgetting to include ongoing documentation maintenance, training time, or incident-handling costs in the total cost picture, making the ROI look better than it really is. (3) Assuming automation equals savings automatically — treating a percentage of automated calls as automatically equivalent to saved money, without checking whether any real staffing or hiring decision actually changed as a result. (4) Using too short a time window — measuring ROI only in the first month, when early costs (training, setup, learning curve) are disproportionately high relative to benefits that haven't fully developed yet, making a genuinely good investment look weak. (5) Comparing against an unrealistic baseline — comparing the AI investment's cost against an unrealistic "do nothing forever" scenario, rather than against the next-best realistic alternative the business would actually have pursued, such as hiring more staff to handle growth.

**Answer 14: B.** The account manager owns the business relationship and manages expectations and emotions; the FDE translates between technical reality and business context and coordinates the right technical response; engineering focuses on deep technical diagnosis and fixing. These typically happen in parallel (relationship management and technical investigation at the same time), not strictly in sequence, because customer trust needs real-time attention throughout an incident, not just after a fix is complete. Options A, C, and D each incorrectly collapse these distinct roles into one person or assign tasks to the wrong role (such as engineering handling all customer communication, which would slow down the actual technical work).

**Answer 15:** De-escalation means using communication techniques to calm a tense, angry, or anxious situation before focusing on solving the underlying technical or business problem — it is about managing the emotional temperature of the conversation first. Acknowledging the customer's feelings before launching into a detailed technical explanation matters because a person in a heightened emotional state often cannot fully absorb detailed information, and jumping straight to explanation can feel dismissive of how they feel, even if the explanation itself is accurate and well-intentioned. Acknowledging the feeling first — showing you understand both the facts and the real impact on them — makes the person calmer and more receptive, so the explanation and eventual solution that follow are actually heard and absorbed properly.
