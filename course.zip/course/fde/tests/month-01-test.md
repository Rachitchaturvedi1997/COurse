# FDE Course — Month 1 Test (Days 1-30)

Answer all 15 questions. Answers are at the end.

---

**Question 1 (Multiple Choice — Role of an FDE, Day 1).** A software company sells a general "voice bot platform." An FDE is sent to make it work for one specific supermarket chain. What is the main difference between the FDE's job and a core product engineer's job?

A) The FDE writes no code at all, only configures settings
B) The FDE makes the product work for one real customer, even writing customer-specific code if needed; the core engineer builds for many future customers in general
C) The FDE only handles sales and pricing, not technical work
D) There is no real difference — both roles do exactly the same work

**Question 2 (Short Answer — FDE vs Software Engineer, Day 3).** For a core Software Engineer, "done" usually means the code passed tests and meets a specification. Explain why "done" means something different, and stricter, for an FDE working directly with one customer.

**Question 3 (Short Answer — Discovery interview technique, Day 7).** A customer tells you, "We want the bot to understand accents better than our current system." Using the 5 whys technique (rephrased as natural follow-up questions, not literally asking "why" five times), write at least three follow-up questions you could use to get from this vague request toward a real root cause.

**Question 4 (Multiple Choice — Stakeholder mapping, Day 8).** On the power/interest grid, a bank's Head of Compliance has very high power (can block go-live with a veto) and is tracking every detail of a new voice bot project closely. How should this stakeholder generally be handled?

A) Monitor with minimum effort, since compliance rarely affects timelines
B) Keep satisfied with brief, infrequent, high-level updates only
C) Manage closely, engaging them early and in depth so their concerns shape the design
D) Ignore them until just before go-live to avoid slowing the project down

**Question 5 (Short Answer — Business basics, Day 9).** An imagined tea stall pays a fixed monthly rent for its spot and buys milk and tea leaves fresh every day based on how much tea it sells. Classify the rent and the milk/tea leaves as fixed or variable costs, and explain in one sentence why the distinction matters when deciding whether selling more tea is worth it.

**Question 6 (Short Answer — Churn and retention, Day 10).** Explain why a "small" monthly churn rate, like 3 percent, can still seriously damage a subscription business's growth over a year, even if the business is also gaining new customers every month at a healthy pace.

**Question 7 (Scenario — Writing for executives, Day 13).** You are the FDE on a voice bot rollout. This week, testing shows the bot handles billing-dispute calls correctly only 75% of the time, well below your 95% target, and you believe the cause is limited training examples for that call type. You are two weeks from go-live. Write a short status update using the Status / Risks / Asks / Next steps structure, starting with a BLUF (Bottom Line Up Front) sentence. Invent reasonable specific details (dates, numbers) as needed.

**Question 8 (Multiple Choice — Logs fundamentals, Day 17).** A voice bot successfully answers a customer's question, but the backend lookup took three times longer than usual to respond. Which log level is most appropriate for recording this event?

A) DEBUG, because it is only useful for deep investigation
B) INFO, because the request technically succeeded
C) WARN, because something unusual happened but the system still completed the request
D) ERROR, because the request failed

**Question 9 (Short Answer — Reading logs effectively, Day 18).** Explain what a correlation ID is, using the bakery "token number" analogy from the lesson, and explain why it is more useful than a customer's phone number alone when investigating exactly what happened during one specific call.

**Question 10 (Short Answer — Traces and observability, Day 19).** Describe the general pattern an experienced FDE follows when investigating a production slowdown: which of metrics, traces, or logs would you look at first, second, and third, and why in that order?

**Question 11 (Scenario — Incident response, Day 21).** At 10:15 AM, a client's voice bot suddenly stops understanding any customer speech at all, dropping nearly every caller to an already-overwhelmed human queue. Your team discovers the root cause is an external speech-recognition provider returning errors, and you have a backup provider already configured for exactly this situation, but switching to it fully will still take about 12 minutes to confirm it is stable. Using what you learned about incident severity and the order of mitigation versus resolution, describe what severity you would assign and what you would do first, and why.

**Question 12 (Multiple Choice — API design fundamentals, Day 23).** Which of the following is the best-designed REST endpoint for retrieving the transcript of one specific call with ID 58213?

A) `/getCallTranscript/58213`
B) `/calls/58213/transcript`
C) `/transcript?action=get&call=58213`
D) `/deleteCall/58213/transcript`

**Question 13 (Short Answer — API authentication, Days 25-26).** In one or two sentences, explain the difference between authentication and authorization, and give one short example of each using a call-centre voice bot connecting to a client's CRM.

**Question 14 (Scenario — SQL investigation, Days 27-28).** A call-centre manager tells you, "Billing calls are taking forever today, and I think it might be one agent, but I'm not sure." You have a `calls` table (`call_id`, `agent_id`, `queue_name`, `start_time`, `duration_seconds`) and an `agents` table (`agent_id`, `agent_name`). Describe, step by step, how you would investigate this using SQL (mention at least SELECT/WHERE, JOIN, and GROUP BY with an aggregate function), and explain why comparing agents' *average* call duration is fairer than just comparing their *raw count* of long calls.

**Question 15 (Short Answer — Real SQL investigation, Day 29).** A client reports that the voice bot's transfer rate "suddenly increased." After confirming the increase with data and finding it is isolated to calls mentioning "dispute charge," you notice the timing lines up closely with a configuration deployment. Why should you still check an independent source, like a deployment log, before reporting this as the confirmed root cause, instead of reporting it as soon as you notice the timing match?

---

## Answer Key

**1. B.** An FDE takes a general-purpose product and makes it work specifically for one real customer, writing customer-specific code or integrations if that is what the customer needs, even if a core product engineer would never write such narrow code. A core product engineer instead builds generally, so the product works reasonably well for many different future customers at once.

**2.** For an FDE, "done" requires that the real customer's own staff have actually used the working system under realistic conditions, and that the customer's own stakeholders agree it works well enough for them — passing automated tests is necessary but not nearly enough. This is stricter than a Software Engineer's "done," which only requires that the code meets an agreed specification and passes testing, with no real customer needing to have used it yet, because the FDE's whole job is tied to one specific customer's real-world success, not an abstract future customer.

**3.** Any three reasonable follow-up questions in the spirit of the lesson, for example: (1) "Can you tell me about a recent, specific call where the accent issue caused a real problem?" (gets a concrete example instead of a vague complaint). (2) "What happened as a result — did the call take longer, get misrouted, or something else?" (surfaces the actual impact). (3) "Is this mostly with certain regions or customer groups, or fairly spread out across callers?" (narrows the scope of the problem). (4) "Has the system ever been retrained or adjusted for this before, or has it always been a known gap?" (surfaces history and whether this has been tried before). A strong answer avoids leading or closed-only questions and digs toward a specific, actionable root cause rather than restating the vague complaint.

**4. C.** A stakeholder with both high power (can veto go-live) and high interest (tracking closely) should be managed closely — engaged early, in depth, before the design is finalized, so their concerns shape the solution rather than arriving as a late veto close to launch.

**5.** The monthly rent is a fixed cost, since it stays the same no matter how many cups of tea are sold. The milk and tea leaves are variable costs, since the amount purchased rises and falls directly with how much tea is made. This distinction matters because once fixed costs are already being paid regardless, each extra cup of tea sold mostly only adds its variable cost, making additional sales proportionally more profitable — which is exactly why businesses care about selling more once their fixed costs are already covered.

**6.** Churn acts every single month, removing a share of the customer base repeatedly, and this effect compounds over time rather than being a one-time event — so even a small monthly churn rate, repeated month after month across a full year, removes a large cumulative share of customers. This can cancel out or badly slow down the effect of steady new-customer growth, because a meaningful share of each month's new customers (and existing customers) keeps leaving again before the business can benefit from the compounding growth that low churn would otherwise allow.

**7.** A model answer (details may reasonably vary): "Status: On track for go-live in two weeks overall, with one specific issue in billing-dispute calls that we are actively fixing. Risks: Billing-dispute calls are currently succeeding only about 75% of the time, below our 95% target; we believe this is due to limited training examples for this call type, and we are adding more examples and retesting this week. Asks: We would like your team to review and approve 15 additional sample billing-dispute call scripts we have drafted, by Wednesday, so we can use them for retraining. Next steps: We will retrain by Thursday, retest over the weekend, and confirm results in next week's update; if the fix is not fully validated in time, we recommend keeping billing-dispute calls routed to human agents at go-live as a fallback." A strong answer leads with a one-sentence BLUF, states the real numbers plainly rather than using vague soft language, and includes a concrete, dated ask and next step.

**8. C.** WARN is correct — the request succeeded (so it is not an ERROR), but something outside the normal, expected pattern happened (unusually slow), which is worth flagging without claiming total failure.

**9.** A correlation ID is a unique reference number generated the moment one request (like one phone call) begins, and it is attached to every single log line written by every component that handles that request — exactly like a bakery giving a customer a token number, so every step of their order (baking, packing, billing) can be found later by searching for that one token. It is more useful than a phone number alone because a phone number can be linked to many different calls across many days, so searching by phone number alone could still return many unrelated calls; a correlation ID is unique to exactly one call, so every log line found using it is guaranteed to belong to that exact one call, with no ambiguity.

**10.** The general pattern is: metrics first, then traces, then logs. Metrics are the cheapest, broadest signal and can tell you quickly and continuously that something across the whole system has changed, and roughly when, even before you know why or where. Traces come next, letting you localize exactly which step or component, within one specific request's journey, is behaving unusually (for example, which span is taking unusually long). Logs come last, giving the fine-grained detail needed to understand precisely why that specific step is failing or slow, once you already know where to look.

**11.** This should be assigned the highest severity tier (commonly called SEV1), because it is a near-total outage of the core function during business hours, affecting nearly all callers with no workaround, and it is actively overwhelming the human team too. Following the mitigate-before-resolve pattern, the first priority is to switch to the already-configured backup speech-recognition provider as quickly as possible to stop the pain for customers right now, even though it takes about 12 minutes to confirm stability — this matters more in the moment than fully understanding or permanently fixing why the original provider failed, which can be investigated properly afterward. Throughout this, the team should also be communicating status to the client on a regular, short cadence, even while the mitigation is still being confirmed.

**12. B.** `/calls/58213/transcript` is correct REST design: endpoints use nouns representing resources (a specific call and its transcript as a sub-resource), with the action ("get") expressed through the HTTP method (GET), not baked into the URL as a verb. The other options either put a verb directly into the URL (A, D) or invent a non-standard action-based query format (C), all of which break the predictable, noun-based pattern that lets other engineers correctly guess how the API works.

**13.** Authentication answers "who are you" — confirming a request genuinely comes from a specific, known identity, such as confirming a request is really coming from Client Company X's dashboard using a credential it was issued. Authorization answers "what are you allowed to do," once identity is known — such as confirming that Client Company X's dashboard is allowed to view this specific client's own call and case data, but never another client's data, even with a perfectly valid credential.

**14.** A reasonable investigation path: first, run a broad SELECT with a WHERE clause narrowing to today's billing-queue calls (`WHERE queue_name = 'billing' AND start_time >= <today>`) to see the shape of the data and spot any unusually long `duration_seconds` values. Then JOIN the `calls` table to the `agents` table on `agent_id` so each call is attached to a real agent name. Finally, use GROUP BY `agent_name` together with aggregate functions — COUNT(*) for how many calls each agent handled, and AVG(duration_seconds) for each agent's typical call length — to compare agents fairly. Comparing AVG(duration_seconds) per agent is fairer than comparing raw counts of long calls, because an agent who simply handles a larger total volume of calls will naturally accumulate more long calls purely by volume, even if nothing is wrong with how they handle any individual call; averaging normalizes for that difference in volume and isolates whether that agent's typical, individual call is actually running long.

**15.** A timing match alone only shows correlation — two things happening around the same time — which is not the same as proof that one caused the other, since with enough deployments happening on a busy platform, something is often deployed near any given anomaly purely by chance. Checking an independent source like a deployment log, and confirming that the specific change's description plausibly explains the specific symptom observed (a change to the dispute-charge flow explaining a dispute-charge-specific transfer spike), turns a merely suspicious pattern into a defensible, verifiable root-cause finding that is safe to act on and report with confidence.
