# FDE + System Design Course — Index

Two complete, self-contained courses built for one learner: a software engineer with 5 years of experience, now a lead AI engineer running a contact-centre voice bot project, aiming for a hire-level role (50-60 LPA in India or higher). Both courses assume you already know programming, APIs, cloud basics, and ML — they do not teach coding from zero.

## How to use this course

1. **Do Part A first, in order.** It is 180 days, about 15 pages (~6000 words) a day. Each day builds on the last.
2. **Take the month test after finishing each month** (after days 30, 60, 90, 120, 150, 180). Tests are in `fde/tests/`. Don't peek at the answer key before attempting all 15 questions.
3. **Then move to Part B**, 100 days, about 25 pages (~10000 words) a day. Take the level test after days 25, 50, 75, 100 (`system-design/tests/`).
4. **One day per sitting is enough.** Each file is self-contained: key words, lessons, a worked example, exercises with answers, interview questions with model answers, a recap, and a one-line preview of tomorrow. FDE days also include a customer conversation script. System design days also include an ASCII diagram, a trade-off table, and an interviewer follow-up question.
5. **Use the exercises and interview questions as a drill, not just reading material.** Cover the answers, try the question yourself, then check.
6. **The capstones are the dress rehearsal.** FDE Day 180 and System Design Day 100 each walk through a full, presentable deployment — use them as templates for your own portfolio case study.
7. If a day was too long for one file, it is split into `day-0NN-part-1.md`, `day-0NN-part-2.md`, etc. — read the parts in order; they are one lesson.

## File layout

```
course/
  fde/
    day-001.md ... day-180.md
    tests/month-01-test.md ... month-06-test.md
  system-design/
    day-001.md ... day-100.md
    tests/level-1-test.md ... level-4-test.md
  README.md   (this file)
```

## Decisions made while building this course

These were made autonomously while writing the course, since the brief gave topics per month/level but not a day-by-day breakdown:

- **Day-by-day topic allocation** within each month (Part A) and level (Part B) was decided by the writing agents, splitting each month's/level's subtopic list across its days and reserving the last 1-2 days of each block for review and/or capstone/test prep. Full breakdowns below.
- **Part B capstone designs (Days 97-100)**: chosen as (1) e-commerce/payments at scale, (2) social/chat mega-platform, (3) AI-native SaaS platform, (4) contact-centre voice platform — covering the brief's requirement of "four capstone designs, including a contact-centre voice platform."
- **File splitting**: no day in either course required a part-1/part-2 split — every day fit in one file.
- **Numbering**: all files are zero-padded to 3 digits (`day-001.md` ... `day-180.md`) for clean sorting.
- **Minor heading-style drift**: a handful of System Design days (16-25, 41-50) use `Day N — Title` instead of `System Design Day N: Title` as their first line, and days 61-65 have one leading blank line before the heading. Content and structure are unaffected; noted here for transparency.
- **Word-count targets**: FDE days target ~6000 words (15 pages); most hit 5300-6300. System Design days target ~10000 words (25 pages); most hit 9300-12800, with a few early Level-3 days (61-65) landing closer to 9300-9500 — still full lessons, not shortened.

## Part A: Forward Deployed Engineer (180 days)

### Month 1 — FDE fundamentals (Days 1-30)
1. FDE Day 1: What an FDE does
2. FDE Day 2: A day in the life of an FDE
3. FDE Day 3: FDE vs Software Engineer
4. FDE Day 4: FDE vs Solutions Engineer vs Consultant vs Customer Success
5. FDE Day 5: Customer discovery fundamentals
6. FDE Day 6: Discovery call structure
7. FDE Day 7: Interview techniques for discovery
8. FDE Day 8: Stakeholder mapping
9. FDE Day 9: Business basics for engineers — revenue, cost, and margin
10. FDE Day 10: Business basics — churn and retention
11. FDE Day 11: Business basics — ROI and the business case
12. FDE Day 12: Business basics — pricing models and unit economics
13. FDE Day 13: Writing for executives — status updates
14. FDE Day 14: Writing for executives — executive summaries and escalation emails
15. FDE Day 15: Communication — handling difficult customer conversations
16. FDE Day 16: Communication — running effective meetings and demos
17. FDE Day 17: Production debugging — logs fundamentals
18. FDE Day 18: Production debugging — reading logs effectively
19. FDE Day 19: Production debugging — traces and observability
20. FDE Day 20: Production debugging — metrics, dashboards, and alerting
21. FDE Day 21: Incident response
22. FDE Day 22: Postmortems and root cause analysis
23. FDE Day 23: API design fundamentals
24. FDE Day 24: API design — status codes, versioning, and pagination
25. FDE Day 25: API authentication — API keys and basic auth
26. FDE Day 26: API authentication — OAuth basics, tokens, and JWT
27. FDE Day 27: SQL for data investigation — SELECT, WHERE, JOIN
28. FDE Day 28: SQL for data investigation — GROUP BY and aggregations
29. FDE Day 29: SQL for data investigation — a real investigation scenario
30. FDE Day 30: Month 1 review and capstone — *month-01-test.md*

### Month 2 — Integrations (Days 31-60)
31. FDE Day 31: Integrating with CRMs — what is a CRM
32. FDE Day 32: Integrating with CRMs — integration patterns
33. FDE Day 33: Ticketing systems — what they are and their objects
34. FDE Day 34: Ticketing systems — integration patterns and field mapping
35. FDE Day 35: Call-centre platforms — IVR, ACD, and call routing basics
36. FDE Day 36: Call-centre platforms — integrating a voice bot
37. FDE Day 37: Webhooks — what they are
38. FDE Day 38: Webhook security — signatures and verification
39. FDE Day 39: Webhooks — retries and idempotency
40. FDE Day 40: Designing a webhook receiver
41. FDE Day 41: Data formats — CSV, structure and encoding
42. FDE Day 42: Data formats — common CSV problems and fixes
43. FDE Day 43: Data formats — JSON structure and nesting
44. FDE Day 44: Data formats — JSON schema validation and JSON vs CSV
45. FDE Day 45: Data formats — Parquet and columnar storage
46. FDE Day 46: Data formats — when to use Parquet, compression, and schema evolution
47. FDE Day 47: ETL fundamentals — extract, transform, load
48. FDE Day 48: ETL — batch vs streaming and pipeline design
49. FDE Day 49: Data quality — the dimensions of data quality
50. FDE Day 50: Data quality — checks and monitoring
51. FDE Day 51: OAuth deep dive — flows
52. FDE Day 52: OAuth deep dive — scopes, refresh tokens, and pitfalls
53. FDE Day 53: SSO — what it is and SAML vs OIDC concept
54. FDE Day 54: Implementing SSO for a customer integration
55. FDE Day 55: Retries and timeouts — timeout strategy
56. FDE Day 56: Retries and timeouts — retry strategies, backoff, and circuit breakers
57. FDE Day 57: Building one end-to-end integration — requirements and design
58. FDE Day 58: Building one end-to-end integration — build
59. FDE Day 59: Building one end-to-end integration — testing and validation
60. FDE Day 60: Going live, handover, and Part A review/capstone — *month-02-test.md*

### Month 3 — Deploying (Days 61-90)
61. FDE Day 61: Cloud compute basics
62. FDE Day 62: Cloud storage basics
63. FDE Day 63: Cloud networking basics
64. FDE Day 64: IAM — Identity and Access Management
65. FDE Day 65: Cloud security basics
66. FDE Day 66: Docker fundamentals
67. FDE Day 67: Docker images and Dockerfiles
68. FDE Day 68: Docker networking, volumes, and docker-compose
69. FDE Day 69: Environments — dev, staging, and production
70. FDE Day 70: Secrets management
71. FDE Day 71: CI/CD concepts
72. FDE Day 72: CI/CD pipelines in practice
73. FDE Day 73: CI/CD for AI/ML systems specifically
74. FDE Day 74: Monitoring basics
75. FDE Day 75: Alerting and incident response
76. FDE Day 76: Deployment model — SaaS (software as a service)
77. FDE Day 77: Deployment model — Private cloud
78. FDE Day 78: Deployment model — On-premise
79. FDE Day 79: Deployment model — Air-gapped
80. FDE Day 80: Comparing deployment models — a decision framework
81. FDE Day 81: Cost basics
82. FDE Day 82: Cost optimization strategies
83. FDE Day 83: Scaling and reliability
84. FDE Day 84: Disaster recovery and backups
85. FDE Day 85: Case study — deploying a voice bot end to end
86. FDE Day 86: Case study — CI/CD for the voice bot project
87. FDE Day 87: Case study — monitoring the voice bot in production
88. FDE Day 88: Troubleshooting deployment issues
89. FDE Day 89: Review Day 1 — cloud infrastructure, Docker, and CI/CD
90. FDE Day 90: Review Day 2 — deployment models, cost, reliability, and a mock phone screen — *month-03-test.md*

### Month 4 — Applied AI (Days 91-120)
91. FDE Day 91: LLM basics in plain words
92. FDE Day 92: How LLMs generate text
93. FDE Day 93: Prompt design fundamentals
94. FDE Day 94: Advanced prompting techniques
95. FDE Day 95: Structured output
96. FDE Day 96: RAG basics
97. FDE Day 97: RAG architecture
98. FDE Day 98: RAG pipeline end-to-end and chunking strategies
99. FDE Day 99: Tool calling basics
100. FDE Day 100: Agents
101. FDE Day 101: Agent architectures and design patterns
102. FDE Day 102: Evaluation basics
103. FDE Day 103: Building test sets for evaluation
104. FDE Day 104: Evaluation metrics
105. FDE Day 105: Guardrails
106. FDE Day 106: Privacy and data protection in AI systems
107. FDE Day 107: Compliance considerations
108. FDE Day 108: Voice AI basics
109. FDE Day 109: Voice AI architecture
110. FDE Day 110: Contact-centre deployment basics
111. FDE Day 111: Contact-Centre Case Study — Designing a Voice Bot End to End
112. FDE Day 112: Handling Escalations and Human Handoff
113. FDE Day 113: Measuring Voice Bot Success
114. FDE Day 114: Common Failure Modes in Voice Bots and Debugging
115. FDE Day 115: Scaling AI Systems for Production
116. FDE Day 116: Security and Guardrails for Voice AI
117. FDE Day 117: Case Study — An End-to-End Applied AI Project
118. FDE Day 118: FDE Role Synthesis — Deployment Meets Applied AI
119. FDE Day 119: Review Day 1 — LLM Basics, Prompting, Structured Output, RAG, and Tool Calling
120. FDE Day 120: Review Day 2 — Evaluation, Guardrails/Privacy, Voice AI, and a Mock Interview — *month-04-test.md*

### Month 5 — Customer delivery (Days 121-150)
121. FDE Day 121: Scoping customer engagements
122. FDE Day 122: Requirements gathering and scope boundaries
123. FDE Day 123: Statements of Work (SOW)
124. FDE Day 124: Designing a pilot program
125. FDE Day 125: Defining success criteria for a pilot
126. FDE Day 126: Running the pilot and tracking metrics
127. FDE Day 127: Pilot-to-production transition
128. FDE Day 128: Preparing a customer demo
129. FDE Day 129: Delivering a demo and handling objections
130. FDE Day 130: Demo environments and demo data
131. FDE Day 131: Security and Compliance Basics for Customer Deployments
132. FDE Day 132: Data Privacy Fundamentals
133. FDE Day 133: India's DPDP Act — Overview and Key Provisions
134. FDE Day 134: Practical DPDP Compliance for FDE Projects
135. FDE Day 135: Security Reviews and Audits for Customer Deployments
136. FDE Day 136: Reliability Concepts — SLAs, SLOs, and SLIs
137. FDE Day 137: Uptime and Availability Targets
138. FDE Day 138: Incident Detection and Response
139. FDE Day 139: Incident Postmortems and Root Cause Analysis
140. FDE Day 140: Monitoring and Alerting for Customer Systems
141. FDE Day 141: Runbooks
142. FDE Day 142: Writing a Runbook — Worked Example
143. FDE Day 143: Handing Off Runbooks to Customer Ops Teams
144. FDE Day 144: Training Customer Teams — Adult Learning Principles
145. FDE Day 145: Delivering Training Sessions
146. FDE Day 146: Train-the-Trainer and Documentation
147. FDE Day 147: Measuring ROI (Return on Investment)
148. FDE Day 148: Building an ROI Case for the Customer
149. FDE Day 149: Handling Escalations
150. FDE Day 150: Defusing and Resolving Escalations — *month-05-test.md*

### Month 6 — Career and capstone (Days 151-180)
151. FDE Day 151: FDE interview formats overview
152. FDE Day 152: Customer role-play interviews — format and what interviewers are testing
153. FDE Day 153: Customer role-play interviews — practice scenarios
154. FDE Day 154: Customer role-play interviews — common mistakes and recovery
155. FDE Day 155: Take-home builds — format, expectations, and time management
156. FDE Day 156: Take-home builds — technical scope decisions
157. FDE Day 157: Take-home builds — presenting to the panel
158. FDE Day 158: Take-home builds — pitfalls and grading criteria
159. FDE Day 159: System design interviews for FDE — overview and frameworks
160. FDE Day 160: System design — customer architecture design example, worked step by step
161. FDE Day 161: System design interviews — scaling and reliability trade-offs
162. FDE Day 162: System design — handling ambiguity and asking clarifying questions
163. FDE Day 163: System design — whiteboarding and communication skills
164. FDE Day 164: STAR behavioural answers — format and structure
165. FDE Day 165: STAR — crafting stories from your own experience
166. FDE Day 166: STAR — difficult and conflict questions
167. FDE Day 167: STAR — leadership and ownership questions
168. FDE Day 168: Portfolio case studies — what makes a good FDE case study
169. FDE Day 169: Portfolio case studies — structuring your case study document
170. FDE Day 170: Portfolio case studies — presenting case studies in an interview
171. FDE Day 171: Portfolio Case Studies
172. FDE Day 172: Mock Interview — Full Customer Role-Play
173. FDE Day 173: Mock Interview — Full System Design
174. FDE Day 174: Mock Interview — Full Behavioural (STAR) and Feedback Framework
175. FDE Day 175: Offer Negotiation — Principles and Preparation
176. FDE Day 176: Offer Negotiation — Tactics and Scripts
177. FDE Day 177: Job Search Plan — Channels, Targeting, and Pipeline Building
178. FDE Day 178: Capstone Part 1 — Project Selection and Design
179. FDE Day 179: Capstone Part 2 — Build Plan and Execution
180. FDE Day 180: Capstone — Full End-to-End Presentation — *month-06-test.md*

## Part B: System Design (100 days)

### Level 1 — Basics (Days 1-25)
1. System Design Day 1: What System Design Is
2. System Design Day 2: Capacity Estimation (Back-of-the-Envelope Math)
3. System Design Day 3: Latency, Throughput, and Percentiles
4. System Design Day 4: Availability vs Consistency, and the "Nines" of Uptime
5. System Design Day 5: The CAP Theorem and Consistency Models
6. System Design Day 6: DNS
7. System Design Day 7: Load Balancers
8. System Design Day 8: Caching Fundamentals
9. System Design Day 9: CDNs (Content Delivery Networks)
10. System Design Day 10: SQL Databases Basics
11. System Design Day 11: NoSQL databases
12. System Design Day 12: SQL vs NoSQL decision framework
13. System Design Day 13: Indexes
14. System Design Day 14: Database replication
15. System Design Day 15: Database sharding and partitioning
16. Day 16 — Message Queues: The Basics
17. Day 17 — Message Queues: Advanced Patterns
18. Day 18 — Putting It All Together: One Full Architecture
19. Day 19 — Design Exercise: URL Shortener, Part 1
20. Day 20 — Design Exercise: URL Shortener, Part 2 (Deep Dive)
21. Day 21 — Design Exercise: Pastebin, Part 1
22. Day 22 — Design Exercise: Pastebin, Part 2
23. Day 23 — Design Exercise: Simple Rate Limiter, Part 1
24. Day 24 — Design Exercise: Simple Rate Limiter, Part 2
25. Day 25 — Level 1 Comprehensive Review — *level-1-test.md*

### Level 2 — Intermediate (Days 26-50)
26. System Design Day 26: REST API design
27. System Design Day 27: gRPC vs REST, protocol buffers, and streaming APIs
28. System Design Day 28: Pagination strategies
29. System Design Day 29: API versioning
30. System Design Day 30: Rate limiting algorithms deep dive
31. System Design Day 31: Consistent hashing part 1
32. System Design Day 32: Consistent hashing part 2 — virtual nodes and real applications
33. System Design Day 33: Idempotency
34. System Design Day 34: Retries and backoff
35. System Design Day 35: Circuit breakers
36. System Design Day 36: Search fundamentals and inverted index — Part 1
37. System Design Day 37: Search fundamentals and inverted index — Part 2
38. System Design Day 38: Object storage fundamentals
39. System Design Day 39: File upload design patterns
40. System Design Day 40: Notification systems
41. Day 41 — News Feed Fan-Out Concepts
42. Day 42 — Design Exercise: News Feed, Part 1
43. Day 43 — Design Exercise: News Feed, Part 2
44. Day 44 — Design Exercise: File Storage System, Part 1
45. Day 45 — Design Exercise: File Storage System, Part 2
46. Day 46 — Design Exercise: Autocomplete / Typeahead Search, Part 1
47. Day 47 — Design Exercise: Autocomplete / Typeahead Search, Part 2
48. Day 48 — Design Exercise: Web Crawler, Part 1
49. Day 49 — Design Exercise: Web Crawler, Part 2
50. Day 50 — Level 2 Comprehensive Review and Capstone — *level-2-test.md*

### Level 3 — Advanced (Days 51-75)
51. System Design Day 51: CAP theorem and PACELC
52. System Design Day 52: Consistency models
53. System Design Day 53: ACID transactions and the distributed transaction problem
54. System Design Day 54: Sagas — orchestration and choreography
55. System Design Day 55: The outbox pattern and change data capture
56. System Design Day 56: Leader election
57. System Design Day 57: Consensus algorithms
58. System Design Day 58: Distributed locks
59. System Design Day 59: Event sourcing
60. System Design Day 60: CQRS
61. System Design Day 61: Stream processing fundamentals
62. System Design Day 62: Stream processing — advanced
63. System Design Day 63: Multi-region architecture
64. System Design Day 64: Data residency and compliance
65. System Design Day 65: Observability — logs, metrics, and traces
66. System Design Day 66: Observability — SLIs, SLOs, and alerting
67. System Design Day 67: Design a payments system — part 1
68. System Design Day 68: Design a payments system — part 2
69. System Design Day 69: Design a ride-matching system — part 1
70. System Design Day 70: Design a ride-matching system — part 2
71. System Design Day 71: Design a distributed cache
72. System Design Day 72: Design chat at scale — part 1
73. System Design Day 73: Design chat at scale — part 2
74. System Design Day 74: Design video streaming
75. System Design Day 75: Level 3 review and mock interview round — *level-3-test.md*

### Level 4 — Architecture (Days 76-100)
76. System Design Day 76: Monolith vs Microservices vs Serverless
77. System Design Day 77: Serverless Architecture Deep Dive
78. System Design Day 78: Multi-Tenant SaaS Architecture
79. System Design Day 79: Security Architecture
80. System Design Day 80: Cost-Aware Architecture
81. System Design Day 81: LLM serving architecture
82. System Design Day 82: RAG architecture
83. System Design Day 83: Vector databases
84. System Design Day 84: Model gateways and LLM routing
85. System Design Day 85: Evaluation loops for AI systems
86. System Design Day 86: Voice bot architecture at scale — part 1
87. System Design Day 87: Voice bot architecture at scale — part 2
88. System Design Day 88: Migrations: the strangler fig pattern
89. System Design Day 89: Zero-downtime deployment and migration techniques
90. System Design Day 90: Architecture Decision Records (ADRs)
91. System Design Day 91: Capacity planning
92. System Design Day 92: Mock interview round 1 — general system design
93. System Design Day 93: Mock interview round 2 — AI system design
94. System Design Day 94: Mock interview round 3 — behavioral and architecture leadership
95. System Design Day 95: Mock interview round 4 — voice bot focused design interview
96. System Design Day 96: Level 4 review and integration
97. System Design Day 97: Capstone 1 — E-commerce and payments platform at scale
98. System Design Day 98: Capstone 2 — Social and chat mega-platform
99. System Design Day 99: Capstone 3 — AI-native SaaS platform
100. System Design Day 100: Capstone 4 — Contact-centre voice platform, full end-to-end design — *level-4-test.md*
